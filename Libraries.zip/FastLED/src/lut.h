#pragma once

#warning "This header is deprecated. Please use lut.h, this header will go away in the version 4.0."

#include "fl/lut.h"