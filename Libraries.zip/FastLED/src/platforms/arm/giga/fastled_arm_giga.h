#ifndef __INC_FASTLED_ARM_GIGA_H
#define __INC_FASTLED_ARM_GIGA_H

#include "fastpin_arm_giga.h"
#include "../../fastspi_ardunio_core.h"
#include "clockless_arm_giga.h"

#endif
