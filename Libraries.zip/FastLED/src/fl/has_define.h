#pragma once

#ifndef __has_include
#define __has_include(x) 0
#endif
